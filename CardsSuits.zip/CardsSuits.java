package com.company;

public enum CardsSuits {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
