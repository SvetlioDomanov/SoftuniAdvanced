package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CardRanks cardRank = CardRanks.valueOf(scanner.nextLine());
        CardsSuits cardsSuit = CardsSuits.valueOf(scanner.nextLine());
        Card card = new Card(cardsSuit,cardRank);

        System.out.printf("Card name: %s of %s; Card power: %d",cardRank,cardsSuit,card.getPower());

    }
}
