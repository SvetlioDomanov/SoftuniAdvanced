package com.company;

public class Card {
    private CardsSuits cardsSuit;
    private CardRanks cardRank;

    public Card(CardsSuits cardsSuit, CardRanks cardRank) {
        this.cardsSuit = cardsSuit;
        this.cardRank = cardRank;
    }
    public int getPower(){
        return cardRank.getRankPower()+cardsSuit.getSuitPower();
    }
}
